# Handoff: Zitch VTU/Bill-Payment Landing Site

## Overview
A 3-page marketing + legal site for **Zitch**, scoped specifically to its bill-payment / VTU (virtual top-up) services — airtime, data, recharge-card PINs, cable TV, electricity, internet, exam PINs and betting-wallet funding. It intentionally **excludes** Zitch's banking/transfers/FX/loans features. It was built for use as a payment-processor / bank verification landing page as well as a public marketing site, so it also ships dedicated Terms & Conditions and Privacy Policy pages linked from the footer.

Pages:
1. `Zitch VTU Landing.html` — the marketing landing page
2. `Zitch Terms and Conditions.html` — legal terms
3. `Zitch Privacy Policy.html` — privacy policy

## About the Design Files
The files in this bundle are **design references built in static HTML/CSS/vanilla JS** — they show the intended look, content and behavior. They are **not production code to copy as-is**. The task is to **recreate this design in the target codebase's existing environment** (React, Next.js, Vue, etc.) using its established component patterns, routing and libraries — or, if no frontend stack exists yet, to choose the most appropriate framework for the project and implement the design there.

The HTML/CSS is fully functional and can be opened directly in a browser as a live reference while implementing.

## Fidelity
**High-fidelity.** Colors, type, spacing, radii, shadows and copy are final. Recreate pixel-faithfully using the codebase's own component library where one exists; only fall back to the raw CSS values below where it doesn't.

## Design system context
This design applies (a retinted version of) a bound design system ("RemoteJobs44") for its structural DNA — type ramp, spacing scale, radii, shadow system, section rhythm — but **all brand colors were overridden to Zitch's actual teal brand** (see Design Tokens below) and the real Zitch logo was substituted for the system's placeholder mark. `_ds/.../colors_and_type.css` in this bundle is the *base* token file (still has some unused blue values in comments/fallbacks); the authoritative colors are the inline `:root` overrides at the top of each HTML file's `<style>` block — copy values from there, not from memory of "RemoteJobs44 blue."

---

## Screens / Views

### 1. Landing page (`Zitch VTU Landing.html`)

**Header** — sticky, 68px tall, `rgba(244,250,249,.92)` background with `backdrop-filter: blur(24px) saturate(180%)`, bottom border `1px solid var(--border-1)`. Contents: logo lockup (image mark + "Zitch" wordmark) left; center nav links (Services, How it works, Pricing, FAQ, Contact) — hidden under 1000px; right: dark-mode toggle icon button, "Get the App" primary button (small), hamburger button (shown under 1000px). Below 1000px a full-width slide-down mobile menu (`.m-menu`) replaces the center nav.

**Hero** — two-column grid (`1.05fr / .95fr`, 56px gap; stacks to 1 column, centered text, under 1000px). Radial glow background (`radial-gradient(ellipse 80% 60% at 50% -10%, rgba(15,162,149,.12), transparent 70%)`).
- Left: eyebrow "AIRTIME · DATA · CABLE · ELECTRICITY", H1 "Recharge and pay every bill — **in seconds.**" (last 3 words highlighted: teal text + translucent amber underline bar), lead paragraph, then App Store + Google Play store-badge buttons (dark pill buttons, icon + two-line label), then a small trust line with a shield-check icon: "PIN-protected payments · instant delivery · receipts for every transaction."
- Right: a phone mockup (320px wide, dark bezel `#0b1220`, 44px corner radius) showing a "Pay a bill" app screen: status bar, greeting, wallet balance (₦48,250.00), "Fund wallet" pill, an 8-tile service grid (Airtime/Data/Cable/Power/PINs/Internet/Exams/Betting, each a 34×34 icon chip + label), and a "Recent" list (2 rows with icon, label, sublabel, amount). Two floating chip callouts overlap the phone: "Airtime delivered · MTN · 3 seconds ago" (top-left) and "DStv renewed · Compact · ₦19,000" (bottom-right), each gently floating via CSS animation (disabled under `prefers-reduced-motion`).

**Provider strip** — full-width band, top/bottom 1px borders, white/card background. Centered uppercase caption "Works with the billers you already use", then a centered flex-wrap row of 7 logo tiles (60px tall, white/app-bg fill, 1.5px border, 14px radius): MTN, Airtel, Glo, 9mobile, DStv, GOtv, StarTimes. Square raster logos (MTN, Glo) render at 40×40 with 8px radius; wide vector logos (Airtel, 9mobile, DStv, GOtv, StarTimes) constrain to 34px tall / 78px max width, `object-fit: contain`.

**Services** (`#services`) — centered section head (eyebrow "What you can pay for", H2 "One app for every top-up and bill", supporting paragraph) then a 4-column card grid (2-col ≤1000px, 1-col ≤560px) of 8 service cards. Each card: 50×50 icon chip (teal-50 bg → fills solid teal on card hover, icon inverts to white), bold title, 2-line description, small pill "tag" (green success-tinted) with a short qualifier. Cards: Airtime top-up, Mobile data bundles, Recharge card printing, Cable & TV, Electricity bills, Internet & broadband, Exam PINs, Betting wallet funding. Cards lift 3px and gain a teal-tinted shadow + border on hover.

**How it works** (`#how`) — tinted section background (`var(--bg-section)`). Centered section head, then a 4-column step row (2-col ≤1000px): each step has a 46×46 numbered teal chip (1–4), a faint oversized outline icon in the top-right corner, bold title, short description. Steps: Download & sign up → Fund your wallet → Pick a service → Get instant delivery.

**Why Zitch** (`#why`) — centered section head, 3-column grid of 6 benefit cards (icon chip + title + 2-line description): Instant delivery, Cashback & fair rates, Everything in one app, Secure by design, Auto-reversals, Real human support.

**Pricing** (`#pricing`) — tinted background, 2-column layout (`.9fr/1.1fr`, stacks ≤1000px). Left: eyebrow "Simple, honest pricing", H2 "No subscriptions. Pay only for what you buy.", then 3 checklist points (green check chip + bold label + description): no monthly/hidden fees, cashback on every recharge, reseller discounts. Right: a "rate card" — dark teal gradient header ("Wallet · ₦0 to open · ₦0 monthly") over a white card body listing 6 rows (icon + label + right-aligned green value): Airtime → up to 3% cashback, Data → up to 5% off, Cable & TV → ₦0 service fee, Electricity → low flat fee, Exam PINs → face value, Recharge PIN printing → reseller rates.

**FAQ** (`#faq`) — centered section head "Questions, answered", then a single-column, max-720px stack of 6 native `<details>` accordions (custom-styled summary row with chevron that rotates 180° when open): What is Zitch? / Which networks & billers are supported? / How fast is delivery? / Is my money and data safe? / What happens if a transaction fails? / How do I fund my wallet?

**Contact** (`#contact`) — tinted background, 2-column layout (stacks ≤1000px). Left: heading "We're here to help" + 4 contact-info rows (icon chip + label + value) for Email, Phone & WhatsApp, Office, Support hours. Right: a card-framed contact form (Full name, Email address, message textarea, submit button) — client-side demo only (see Interactions).

**Get the app / CTA** (`#get`) — full-width solid teal band (`var(--brand-700)`, white text), centered content: H2 "Everything you pay for, in one app.", supporting line, then centered App Store + Google Play badges (light/white variant).

**Footer** — deep teal background (`var(--brand-900)`). 4-column grid (2-col ≤1000px, 1-col ≤560px): brand column (logo + description + small store badges), Services links, Company links, Legal links (Terms & Conditions, Privacy Policy, Refund Policy anchor, Support). Base bar below a hairline divider: copyright line with placeholder legal-entity/RC/address text, and "🇳🇬 Made for Nigeria".

### 2. Terms & Conditions (`Zitch Terms and Conditions.html`) and 3. Privacy Policy (`Zitch Privacy Policy.html`)
Both share one layout: sticky slim header (logo + "Back to site" link + dark-mode toggle) → title band (eyebrow "Legal", H1, "Last updated" pill with calendar icon, one-line lead) → two-column document body (238px sticky table-of-contents + max-720px content column; ToC collapses to a static 2-column box above the content ≤900px) → simple dark footer (logo + Home / other-legal-page / Contact links + copyright).

Content structure: numbered `<h2>` sections (`01`–`17` for Terms, `01`–`14` for Privacy), each `scroll-margin-top` offset for anchor-jump/ToC use, with body paragraphs, bullet lists, and one highlighted "callout" box per document (Terms: "Zitch is a bill-payment and VTU service — not a bank"; Privacy: "we do not store your full card number/CVV/bank credentials"). See the live files for full legal copy — Terms covers acceptance, definitions, eligibility, account, services list, wallet/funding, transactions & delivery, fees/cashback, refunds & reversals (anchor `#refunds`), acceptable use, third-party billers, IP, liability, suspension, changes, governing law, contact. Privacy covers who-we-are, information collected, how it's used, legal basis, sharing, payment info, retention, security, cookies, user rights, children, international transfers, changes, contact.

**⚠️ Placeholder content — replace before shipping.** Every value wrapped in `<span class="ph">…</span>` (a dotted-underline visual marker) is a placeholder and must be replaced with the real business details: legal entity name ("Zitch Technologies Ltd"), RC number ("RC 0000000"), office address ("1 Example Close, Victoria Island, Lagos, Nigeria"), support/legal/privacy email addresses (`support@zitch.ng`, `legal@zitch.ng`, `privacy@zitch.ng`), and phone/WhatsApp number ("+234 800 000 0000"). Grep for `class="ph"` across all 3 files to find every instance (footer copyright lines included).

---

## Interactions & Behavior

- **Dark mode toggle** — icon button in the header on all 3 pages. Toggles `data-theme="dark"|"light"` on `<body>`, swaps the icon (sun/moon), and persists the choice to `localStorage['zvtu-theme']`, read back on load. All colors are CSS custom properties so the whole page re-themes; no re-render needed.
- **Mobile menu** (landing only) — hamburger button toggles an `.open` class on a fixed full-width overlay panel; clicking any link inside it closes it.
- **Scroll-reveal** — elements with class `.rev` fade + translate up into place using `IntersectionObserver` (threshold 0.12), respecting `prefers-reduced-motion`; a safety-net timeout force-reveals anything still hidden after 2.6s (covers hidden tabs / IO edge cases). Stagger via inline `style="--d:.08s"` etc.
- **Floating hero chips** — two absolutely-positioned callout chips beside the phone mockup float via a `translateY` CSS keyframe loop (5s, alternate), offset with an animation-delay; disabled under reduced motion.
- **FAQ accordions** — native `<details>/<summary>`, no JS required; chevron rotation is a pure CSS transform keyed on the `[open]` attribute.
- **Contact form** (landing `#contact`) — client-side only: `preventDefault()` on submit, swaps the button label to "Message sent ✓" and updates a helper note. **No backend wiring** — needs a real submit handler (email service, CRM webhook, etc.) in the target codebase.
- **Legal-page ToC active state** — `IntersectionObserver` over each `<section>` (rootMargin `-40% 0 -55% 0`) toggles an `.active` class on the matching ToC link as the reader scrolls.
- **Icons** — [Lucide](https://lucide.dev/) icons loaded from `https://unpkg.com/lucide@latest` and instantiated via `lucide.createIcons()` on load and after any dynamic icon injection (theme toggle re-render).

## State Management
Minimal — this is a static site:
- `theme` (`'light' | 'dark'`) — persisted in `localStorage['zvtu-theme']`, shared key across all 3 pages so the theme choice carries over between them.
- Mobile menu open/closed — transient DOM class, no persistence.
- Contact form fields — uncontrolled native inputs; no state beyond the DOM until a real submit handler is implemented.
- FAQ open/closed — native `<details>` state, no JS state.

No data fetching in this build. A production implementation will need: wallet/balance data, transaction history (for a real "Recent" list), and a contact-form submit endpoint.

---

## Design Tokens
All tokens are CSS custom properties. Base scale (type ramp, spacing, radii, motion) comes from `_ds/.../colors_and_type.css`; **color tokens below are the authoritative Zitch values**, overridden inline in each page's `<style>` — do not use the blue defaults still present in the linked base file.

**Brand (teal) — light mode**
```
--brand-50:  #E6F7F4     --brand-600: #0FA295  (primary / links / eyebrows)
--brand-100: #C2EDE7     --brand-700: #00847B  (primary button bg, CTA band bg)
--brand-200: #8FDDD4     --brand-800: #00615A  (button hover)
--brand-300: #54C9BD     --brand-900: #043C37  (footer bg)
--brand-400: #2BBAAF     --brand-950: #04221F
--brand-500: #12A99B
```
**Accent:** `#F5A623` (amber — hero-highlight underline, small "delivered" chip icon only; never used for primary actions)

**Surfaces — light / dark**
```
--bg-app:     #F4FAF9 / #04211D
--bg-section: #E9F5F2 / #062B26   (alternating tinted sections)
--bg-card:    #FFFFFF / #0A362F
--border-1:   #DCEDE9 / #123F38   (card borders)
--border-2:   #CFE5E0 / #174B42   (input/chip borders)
--border-3:   #E9F5F2 / #0B2E29   (hairlines)
```
**Text (unchanged from base system):** `--fg-1:#0f172a` (primary) · `--fg-2:#475569` (body) · `--fg-3:#64748b` (tertiary) · `--fg-4:#94a3b8` (meta/placeholder)

**Semantic:** `--success:#1ea05e` / `--success-bg:#edfaf2` (cashback tags, check icons) · `--warning:#f59e0b` · `--danger:#ef4444`

**Shadows (teal-tinted, not neutral gray):**
```
--shadow-sm-brand: 0 1px 4px rgba(0,132,123,.08)
--shadow-md-brand: 0 4px 20px rgba(0,132,123,.18)   (default card-hover / button)
--shadow-lg-brand: 0 8px 32px rgba(0,132,123,.20)
--shadow-xl-brand: 0 16px 56px rgba(0,132,123,.24)  (phone mockup)
```

**Typography**
- Display / headings / buttons / eyebrows: **Sora**, weights 400–800 (headings use 800/extrabold; eyebrows use 700 + `letter-spacing: .14em` uppercase)
- Body / paragraphs / nav / form fields: **DM Sans**, 400–500
- Loaded via Google Fonts `<link>` (both) with local variable-font `.ttf` fallback in `_ds/.../fonts/`
- Scale: 10 / 11 / 13 / 15(base) / 17 / 20 / 24 / 30 / 38 / 50 / 64px; headline tracking `-0.02em`, eyebrow tracking `0.06–0.1em`

**Radii:** cards/tiles/buttons `14px` (the system's specific card radius, not its generic 16px token) · brand mark `10–11px` · pill/badge/chip `9999px`

**Spacing:** 4px base scale — 4/8/12/16/20/24/32/40/48/64px. Section vertical padding `92px` desktop → `64px` ≤560px. Container max-width `1200px` (landing) / `1080px` (legal docs), `24px` side padding (`18px` ≤560px).

**Motion:** `150ms` color/hover, `200ms` transform, `300ms` modal/reveal-adjacent; standard `ease` plus a spring `cubic-bezier(0.34,1.56,0.64,1)` used for the floating hero chips.

---

## Assets
- **Logo:** `uploads/zitch-logo.png` — 256×256px PNG, downscaled from the user-supplied `uploads/zitchlogo4096.png` (full-bleed teal ribbon "Z" mark on a dark teal-navy gradient square — an app-icon-style lockup, not a transparent mark). Used at 34–38px, `border-radius: 10–11px`, `object-fit: cover`, in every header/footer/mobile-menu brand lockup alongside a "Zitch" Sora wordmark.
- **Provider logos:** `assets/logos/` — `mtn.jpg`, `airtel.svg`, `glo.jpg`, `9mobile.svg`, `dstv.svg`, `gotv.svg`, `startimes.png`. Real third-party brand marks — keep as-is, do not recolor.
- **Icons:** Lucide (outline), CDN-loaded, ~1.75 stroke width. Icon names used: `menu`, `x`, `sun`, `moon`, `shield-check`, `check`, `tv`, `smartphone`, `wifi`, `zap`, `credit-card`, `globe`, `graduation-cap`, `dice-5`, `plus`, `download`, `wallet`, `mouse-pointer-click`, `badge-check`, `rocket`, `piggy-bank`, `layout-grid`, `lock`, `rotate-ccw`, `headset`, `chevron-down`, `mail`, `phone`, `map-pin`, `clock`, `arrow-left`, `calendar`.
- **Store badges:** hand-drawn inline SVG (Apple + Google Play glyphs), not image files.
- No photography/illustration is used anywhere in this design (consistent with the base design system's "no imagery" marketing convention).

## Files
- `Zitch VTU Landing.html` — main landing page (self-contained HTML/CSS/JS)
- `Zitch Terms and Conditions.html` — Terms & Conditions document
- `Zitch Privacy Policy.html` — Privacy Policy document
- `_ds/remotejobs44-design-system-01e971a1-a75c-46a8-961e-ce72965a5e0a/colors_and_type.css` + `styles.css` + `fonts/` — base design-system tokens/fonts the pages link to (color tokens are overridden per-page; see Design Tokens above for the values that actually render)
- `assets/logos/` — provider logo images
- `uploads/zitch-logo.png` — Zitch brand mark used throughout

All three HTML files are fully self-contained and can be opened directly in a browser (double-click / drag into a tab) to see the live, interactive reference — including dark mode, the FAQ accordions, and the phone-mockup hero.
